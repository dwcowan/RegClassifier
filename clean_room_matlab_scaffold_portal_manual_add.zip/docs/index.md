# Projects Portal

- [regulatory_classifier](regulatory_classifier/index.html)

> Use the scripts to add new projects and this index will be updated.

## Add a new project
From a developer machine:

```bash
python scripts/add_project.py --ns foo --title "Foo Project" --docs-id foo
```

Or on Windows:

```bat
scripts\win\add_project.bat foo "Foo Project" foo
```



# Projects Portal

This site indexes project documentation and gives you **copy‑paste commands** to add a new project namespace on the Synology server.

---

## Add New Project (manual, secure)

> Runs on the Synology box over VPN/SSH. This avoids exposing any write endpoints via the public site.

1. **SSH into Synology** (behind VPN)
    ```bash
    ssh <user>@<synology-host-or-ip>
    ```

2. **Switch to the repo directory**
    ```bash
    cd /volume1/repos/<your-repo-folder>
    git pull
    ```

3. **Run the scaffold** (replace placeholders)
    ```bash
    python3 scripts/add_project.py --ns <namespace> --title "<Project Title>" --docs-id <docs_id>
    ```

    - `<namespace>` → MATLAB package name (e.g., `foo` yields package `+foo` and error IDs `foo:model:...`).
    - `<Project Title>` → human-friendly display title.
    - `<docs_id>` → folder under `docs/` for this project’s site (usually same as `<namespace>`).

4. **Snapshot the API (from MATLAB, optional to do later)**
    ```matlab
    addpath('tools'); snapshot_api
    ```

5. **Build docs locally (if building on Synology)**
    ```bash
    pip3 install mkdocs mkdocs-material --user
    mkdocs build -f docs/<docs_id>/mkdocs.yml
    rsync -av --delete docs/<docs_id>/site/ <user>@<synology-host-or-ip>:/volume1/web/<docs_id>/
    ```

### Example (creates `+foo`)

```bash
ssh dev@syno.example.local
cd /volume1/repos/my-matlab-repo
git pull
python3 scripts/add_project.py --ns foo --title "Foo Project" --docs-id foo
```

After this:
- Source: `+foo/` with correct package names and error IDs.
- Tests: `tests/+foo/` mirrored and retagged.
- Docs: `docs/foo/` with a standalone MkDocs config.
- The **Projects Portal** gets a new link to `/foo/` automatically.

---

## Security & policy

- **Do not** try to run server‑side code from this page. It’s a static site on Synology Web Station for safety.
- The scaffold script **writes to the repo**, so use SSH behind the VPN and your normal Git flow.
- Only namespaces that pass `tools.check_style` and `tools.check_contracts` should be merged.
