#!/usr/bin/env python3
# add_project.py — scaffold a new MATLAB project namespace and docs.
# Usage: python scripts/add_project.py --ns foo --title "Foo Project" --docs-id foo_project
import argparse, os, re, shutil, json, sys

REPO_ROOT = os.path.dirname(os.path.abspath(__file__))
REPO_ROOT = os.path.abspath(os.path.join(REPO_ROOT, os.pardir))

def die(msg):
    print(f"[add_project] ERROR: {msg}", file=sys.stderr)
    sys.exit(1)

def valid_ns(ns):
    # MATLAB package names must start with letter and contain letters, digits, underscores
    return re.match(r"^[A-Za-z][A-Za-z0-9_]*$", ns) is not None

def replace_in_file(path, subs):
    with open(path, "r", encoding="utf-8") as f:
        txt = f.read()
    for old, new in subs.items():
        txt = txt.replace(old, new)
    with open(path, "w", encoding="utf-8") as f:
        f.write(txt)

def copytree(src, dst):
    if os.path.exists(dst):
        die(f"Destination already exists: {dst}")
    shutil.copytree(src, dst)

def ensure_dir(p):
    os.makedirs(p, exist_ok=True)

def update_docs_portal(project_id):
    portal = os.path.join(REPO_ROOT, "docs", "index.md")
    ensure_dir(os.path.dirname(portal))
    lines = []
    if os.path.exists(portal):
        with open(portal, "r", encoding="utf-8") as f:
            lines = f.read().splitlines()
    link = f"- [{project_id}](./{project_id}/index.html)"
    if link not in lines:
        # Append link under top section
        with open(portal, "a", encoding="utf-8") as f:
            f.write(f"\n{link}\n")

def main():
    ap = argparse.ArgumentParser(description="Scaffold a new MATLAB project namespace and docs.")
    ap.add_argument("--ns", required=True, help="MATLAB package namespace (e.g., foo -> +foo/)")
    ap.add_argument("--title", required=False, default=None, help="Human-friendly project title")
    ap.add_argument("--docs-id", required=False, default=None, help="Docs folder name (default = ns)")
    args = ap.parse_args()

    ns = args.ns
    if not valid_ns(ns):
        die("Invalid namespace. Use letters, digits, underscores; start with a letter. Example: analytics_core")

    docs_id = args.docs_id or ns
    title = args.title or ns

    # 1) Duplicate +reg/* to +<ns>/*
    src_pkg = os.path.join(REPO_ROOT, "+reg")
    if not os.path.isdir(src_pkg):
        die(f"Template package not found: {src_pkg}")
    dst_pkg = os.path.join(REPO_ROOT, f"+{ns}")
    copytree(src_pkg, dst_pkg)

    # Replace package references 'reg.' -> '<ns>.' and error IDs 'reg:' -> '<ns>:'
    for base, _, files in os.walk(dst_pkg):
        for name in files:
            if name.endswith(".m"):
                p = os.path.join(base, name)
                replace_in_file(p, {"reg.": f"{ns}.", "reg:": f"{ns}:"})

    # 2) Duplicate tests tree under tests/+reg -> tests/+<ns>
    src_tests = os.path.join(REPO_ROOT, "tests", "+reg")
    if os.path.isdir(src_tests):
        dst_tests_ns = os.path.join(REPO_ROOT, "tests", f"+{ns}")
        copytree(src_tests, dst_tests_ns)
        for base, _, files in os.walk(dst_tests_ns):
            for name in files:
                if name.endswith(".m"):
                    p = os.path.join(base, name)
                    replace_in_file(p, {"reg.": f"{ns}.", "reg:": f"{ns}:"})

    # 3) Docs: duplicate docs/regulatory_classifier -> docs/<docs_id>
    src_docs = os.path.join(REPO_ROOT, "docs", "regulatory_classifier")
    if os.path.isdir(src_docs):
        dst_docs = os.path.join(REPO_ROOT, "docs", docs_id)
        copytree(src_docs, dst_docs)
        # Replace occurrences
        replacements = {
            "regulatory_classifier": docs_id,
            "reg.": f"{ns}.",
            "+reg": f"+{ns}",
            "reg(": f"{ns}(",
            "reg:": f"{ns}:",
            "reg ": f"{ns} ",
        }
        for base, _, files in os.walk(dst_docs):
            for name in files:
                if name.endswith((".md", ".yml", ".txt")):
                    p = os.path.join(base, name)
                    replace_in_file(p, replacements)

    # 4) Update docs portal index
    update_docs_portal(docs_id)

    # 5) Print next steps
    print("[add_project] Scaffold complete.")
    print(f" - Source package: +{ns}/ (copied from +reg/)")
    print(f" - Tests: tests/+{ns}/")
    print(f" - Docs: docs/{docs_id}/ (copied from docs/regulatory_classifier)")
    print("Next steps:")
    print("  1) Run MATLAB to snapshot API for the new namespace:")
    print("     matlab -batch \"addpath('tools'); snapshot_api\"")
    print("  2) Commit and push the new project.")
    print("  3) Build docs and publish to Synology:")
    print(f"     mkdocs build -f docs/{docs_id}/mkdocs.yml && rsync -av --delete docs/{docs_id}/site/ user@synology:/volume1/web/{docs_id}/")

if __name__ == '__main__':
    main()
