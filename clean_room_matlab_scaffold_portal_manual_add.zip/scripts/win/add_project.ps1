param(
  [Parameter(Mandatory=$true)][string]$Namespace,
  [string]$Title = $null,
  [string]$DocsId = $null
)
if (-not $DocsId) { $DocsId = $Namespace }
$script = Join-Path (Split-Path -Parent $PSScriptRoot) "add_project.py"
python $script --ns $Namespace --title $Title --docs-id $DocsId
