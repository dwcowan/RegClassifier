# Project Tests

Place your project tests here (e.g., `tests/+<ns>`). Example tests were moved to `examples/tests/+reg/`.